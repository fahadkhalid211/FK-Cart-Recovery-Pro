<?php
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only date filter params, no data mutation
defined( 'ABSPATH' ) || exit;

$from = sanitize_text_field( isset( $_GET['date_from'] ) ? wp_unslash( $_GET['date_from'] ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) ) );
$to   = sanitize_text_field( isset( $_GET['date_to'] )   ? wp_unslash( $_GET['date_to'] )   : gmdate( 'Y-m-d' ) );
// phpcs:enable

$stats    = CAR_Analytics::summary( $from, $to );
$products = CAR_Analytics::products( 15 );
$rate     = CAR_Analytics::recovery_rate( $from, $to );
$currency = get_woocommerce_currency_symbol();

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$email_stats = $wpdb->get_results(
    "SELECT c.name, c.channel,
        COUNT(l.id) as sent,
        SUM(l.open_count > 0) as opened,
        SUM(l.click_count > 0) as clicked,
        SUM(l.unsubscribed) as unsubscribed
    FROM {$wpdb->prefix}car_email_logs l
    JOIN {$wpdb->prefix}car_campaigns c ON l.campaign_id = c.id
    WHERE l.status = 'sent'
    GROUP BY l.campaign_id
    ORDER BY sent DESC"
);
?>
<div class="wrap car-admin-wrap">
    <?php include __DIR__ . '/partials/header.php'; ?>

    <!-- Date Filter -->
    <div class="car-card car-filter-card">
        <form method="get" class="car-date-form">
            <input type="hidden" name="page" value="car-pro-reports" />
            <label><?php esc_html_e( 'From:', 'fk-cart-recovery' ); ?> <input type="date" name="date_from" value="<?php echo esc_attr( $from ); ?>" class="car-input car-input-sm" /></label>
            <label><?php esc_html_e( 'To:', 'fk-cart-recovery' ); ?> <input type="date" name="date_to" value="<?php echo esc_attr( $to ); ?>" class="car-input car-input-sm" /></label>
            <button class="car-btn car-btn-sm"><?php esc_html_e( 'Apply', 'fk-cart-recovery' ); ?></button>
        </form>
    </div>

    <!-- Summary Stats -->
    <div class="car-kpi-grid">
        <div class="car-kpi-card car-kpi--blue">
            <div class="car-kpi-value"><?php echo esc_html( $stats['total_abandoned'] ); ?></div>
            <div class="car-kpi-label"><?php esc_html_e( 'Total Abandoned', 'fk-cart-recovery' ); ?></div>
        </div>
        <div class="car-kpi-card car-kpi--green">
            <div class="car-kpi-value"><?php echo esc_html( $stats['total_recovered'] ); ?></div>
            <div class="car-kpi-label"><?php esc_html_e( 'Recovered', 'fk-cart-recovery' ); ?></div>
        </div>
        <div class="car-kpi-card car-kpi--orange">
            <div class="car-kpi-value"><?php echo esc_html( $rate ); ?>%</div>
            <div class="car-kpi-label"><?php esc_html_e( 'Recovery Rate', 'fk-cart-recovery' ); ?></div>
        </div>
        <div class="car-kpi-card car-kpi--purple">
            <div class="car-kpi-value"><?php echo esc_html( $currency . number_format( (float) $stats['abandoned_value'], 2 ) ); ?></div>
            <div class="car-kpi-label"><?php esc_html_e( 'Abandoned Revenue', 'fk-cart-recovery' ); ?></div>
        </div>
        <div class="car-kpi-card car-kpi--teal">
            <div class="car-kpi-value"><?php echo esc_html( $currency . number_format( (float) $stats['recovered_value'], 2 ) ); ?></div>
            <div class="car-kpi-label"><?php esc_html_e( 'Recovered Revenue', 'fk-cart-recovery' ); ?></div>
        </div>
    </div>

    <div class="car-reports-row">

        <!-- Campaign Email Performance -->
        <div class="car-card car-card-full">
            <div class="car-card-header"><h3><?php esc_html_e( 'Campaign Performance', 'fk-cart-recovery' ); ?></h3></div>
            <?php if ( $email_stats ) : ?>
            <table class="car-table">
                <thead><tr>
                    <th><?php esc_html_e( 'Campaign', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Channel', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Sent', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Open Rate', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Click Rate', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Unsubscribes', 'fk-cart-recovery' ); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ( $email_stats as $row ) :
                    $open_rate  = $row->sent ? round( $row->opened  / $row->sent * 100, 1 ) : 0;
                    $click_rate = $row->sent ? round( $row->clicked / $row->sent * 100, 1 ) : 0;
                ?>
                <tr>
                    <td><strong><?php echo esc_html( $row->name ); ?></strong></td>
                    <td><span class="car-channel-badge car-channel--<?php echo esc_attr( $row->channel ); ?>"><?php echo esc_html( ucfirst( $row->channel ) ); ?></span></td>
                    <td><?php echo esc_html( $row->sent ); ?></td>
                    <td>
                        <div class="car-progress-bar"><div class="car-progress-fill" style="width:<?php echo esc_attr( min( 100, $open_rate ) ); ?>%"></div></div>
                        <?php echo esc_html( $open_rate ); ?>%
                    </td>
                    <td>
                        <div class="car-progress-bar"><div class="car-progress-fill car-progress-fill--green" style="width:<?php echo esc_attr( min( 100, $click_rate ) ); ?>%"></div></div>
                        <?php echo esc_html( $click_rate ); ?>%
                    </td>
                    <td><?php echo esc_html( $row->unsubscribed ); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else : ?>
            <p class="car-empty"><?php esc_html_e( 'No email data yet.', 'fk-cart-recovery' ); ?></p>
            <?php endif; ?>
        </div>

        <!-- Product Stats -->
        <div class="car-card car-card-full">
            <div class="car-card-header"><h3><?php esc_html_e( 'Product-Level Abandonment', 'fk-cart-recovery' ); ?></h3></div>
            <?php if ( $products ) : ?>
            <table class="car-table">
                <thead><tr>
                    <th><?php esc_html_e( 'Product', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Abandoned', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Recovered', 'fk-cart-recovery' ); ?></th>
                    <th><?php esc_html_e( 'Recovery Rate', 'fk-cart-recovery' ); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ( $products as $p ) :
                    $pr = ( $p['abandoned'] + $p['recovered'] ) > 0 ? round( $p['recovered'] / ( $p['abandoned'] + $p['recovered'] ) * 100, 1 ) : 0;
                ?>
                <tr>
                    <td><?php echo esc_html( $p['name'] ?: '#' . $p['id'] ); ?></td>
                    <td><?php echo esc_html( $p['abandoned'] ); ?></td>
                    <td><?php echo esc_html( $p['recovered'] ); ?></td>
                    <td>
                        <div class="car-progress-bar"><div class="car-progress-fill car-progress-fill--blue" style="width:<?php echo esc_attr( min( 100, $pr ) ); ?>%"></div></div>
                        <?php echo esc_html( $pr ); ?>%
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else : ?>
            <p class="car-empty"><?php esc_html_e( 'No product data yet.', 'fk-cart-recovery' ); ?></p>
            <?php endif; ?>
        </div>

    </div>
</div>
